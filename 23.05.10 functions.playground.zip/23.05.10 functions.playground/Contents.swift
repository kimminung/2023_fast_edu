import UIKit

//function?

//- 어떤 태스크를 수행하기 위한 코드 블록
//- 이 코드 블록을 수행하기 위해서 이름을 붙이고, 이것을 호출해서, 해당 코드를 수행함
//    - → 여러 곳에서 재사용 가능
//    - → DRY (Don’t Repeat Yourself)

//function 작성하기

//- `func` 키워드를 이용해서 생성
//- 함수의 구성요소
//    - (필수) 함수 이름
//    - (선택) 인풋
//    - (선택) 아웃풋
//- `<함수이름>()` 을 통해서 실제 함수 수행 시킴

// 초심플 함수

func printHello() {
    print("Hello Swift World! 🔥🔥")
}

printHello() // "Hello Swift World! 🔥🔥"

//input parameter 받기

//- 함수는 필요한 데이터를 받을수 있음
//- 넘겨 받을 인풋에 대해서, `이름`과 `타입`을 정해주어야함
//    - `( )` 안에 필요한 인자들을 정의해야함


func printName(name: String) {
    print("name is \(name)")
}

printName(name: "Jason") // "name is Jason"


//output 값 반환하기

//- 함수는 데이터를 반환할수도 있음
//- 반환할 아웃풋에 대해서 `타입`을 정해주어야함
//- 함수 내부에서는 `return` 키워드를 통해서 아웃풋을 반환시킴

func makeDouble(num: Int) -> Int {
    return num * 2
}

let result = makeDouble(num: 3)

print(result) // 6


//input parameter label

//- 앞서서 input parameter 의 `이름`을 정해주었음
//- parameter 를 호출하는 외부, 내부 관점에서 보았을때 이름을 다르게 하는 것이 더 자연스러울때가 있음
//    - → 결국 코드는 가독성을 높여, 동료 개발자들이 이해하기 쉬워야 하니까
//    - → 앞서 만들었던 `printName` 의 경우 호출시 어색함이 있음
//        - `printName(name: "Jason")`
//        - name 이 중복으로 들어간 느낌임
//        - 해당 함수를 개선한 형태는 아래예제로 확인



// 외/내부 paramter label 변경 -> 호출할때 더 읽기 쉬움
func printName(of name: String) {
    print("name is \(name)")
}

printName(of: "Jason") // "name is Jason"


// 외부 paramter 를 생략하고 싶은 경우 -> 호출할때 더 읽기 쉬움
func printName(_ name: String) {
    print("name is \(name)")
}

printName("Jason") // "name is Jason"
