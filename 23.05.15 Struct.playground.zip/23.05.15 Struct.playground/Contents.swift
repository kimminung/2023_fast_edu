import UIKit

struct Student {
    let name: String
    var major: String
    var knowledge: Double
    
    func didFinalTest() -> Int {
        let howMuchIdontKnow = (1 - knowledge) * 100
        let score = 100 - Int(howMuchIdontKnow)
        return score
    }
    
    mutating func didStudy() {
        if knowledge >= 1 {
            knowledge = 1
        } else {
            knowledge += 0.1
        }
    }
}


var student = Student(name: "Jason", major: "CS", knowledge: 0.5)

let score1 = student.didFinalTest()

student.didStudy()
student.didStudy()

let score2 = student.didFinalTest()

// student.name = "ddd" // 에러 발생

let str: String = "Hello Swift"

print(str.count)  //  11

print(str.sorted())  //  [" ", "H", "S", "e", "f", "i", "l", "l", "o", "t", "w"]
print(str.split(separator: " "))  // ["Hello", "Swift"]
print(str.uppercased())  // HELLO SWIFT
print(str.hasPrefix("Hi")) // false
