import UIKit

//variable 변수
var greeting = "Hello, playground"

var str = "Hello, swift"
str = "Hello world"

str

str


var age = 20
// age = "Hi" -> Int 타입으로 이미 지정되어서 String 타입 넣을수 없음

// 큰숫자는 "_" 를 써서 읽기 쉽게 숫자를 표현할수 있음
var money = 2_000_000
var price = 1000200

var name = "Jason"
name = "Jin"

var gpa = 4.5
var isEnabled = false


//String Interpolation

var height = 180

var text = "his height is \(height) "



//Constant

let dj = "koo"
// dj = "goo" -> 시도하면 에러 발생, 상수는 할당된 값을 변경할수 없기 때문



//Type Annotation

// 명시적 타입 기입 없을때 -> 타입추론
var weeks = 10
var token = "qwer123"

// 명시적 타입 기입
var days: Int = 5
var userName: String = "Jake"



//swift: array,  dictionary, set / enum

//array
//- 여러 데이터를 순서대로 담아 놓은 변수
//- `[ ]` 를 이용해서 선언
//- 개별 아이템 접근시 index 를 이용함
//    - index 는 0 부터 시작함
//    - 순서에서 벗어난 index 를 요청하면 크래시가 발생

let yoo = "유재석"
let ji = "지석진"
let ha = "하하"
let so = "전소민"
let song = "송지효"
let kim = "김종국"


let runningMans = [yoo, ji, ha, so, song, kim]

runningMans[0] // -> 유재석
runningMans[1] // -> 지석진
runningMans[5] // -> 김종국

// 비어 있는 배열 초기화
var emptyArr: [Int] = [] // [Int]()로도 표현

emptyArr = [Int]()

var emptyArr2 = [Int]()

//dictionary

// Dictionary (Key: Value)
//let languageCode = [
let languageCode: [String: String] = [
    "한국" : "ko",
    "미국" : "en",
    "일본" : "ja",
]

languageCode["한국"] // "ko"
languageCode["베트남"] // nil

// 비어 있는 딕셔너리 초기화
var emptyDic: [String: Any] = [:] // [String: Any]()로도 표현
emptyDic = [String: Any]()



//# set
//
//- 여러 데이터를 순서 상관없이, 그리고 중복없이 담아 놓은 변수
//- array 와 차이점
//    - 순서가 없다 (랜덤 순서다)
//    - 중복 데이터를 들고 있지 않는다


var primes: Set<Int> = [2, 3, 5, 7]

//type anotation 안하면 array로 잡힘
var primes2 = [2, 3, 5, 7]

// 중복 데이터 넣으려고 시도하면, 중복된것 알아서 무시됨
var evens = Set<Int>([2, 4, 6, 8, 2, 4])

// 비어 있는 set 초기화
var emptySet: Set<Int> = [] // Set<Int>()로도 표현

emptySet = Set<Int>()



//tuple

//- 여러 데이터를 하나의 값으로 표현
//- 세부 데이터 접근시, 포지션 또는 이름으로 접근 가능

var phone = (os: "iOS", model: "iPhone13")

phone.0 // "iOS"
phone.1
//phone.2 //Value of tuple type '(os: String, model: String)' has no member '2'
phone.os // "iOS"

var rawPhone = ("iOS", "iPhone13")
rawPhone.0
rawPhone.1



//enum  열거형

//- 서로 관계있는 값들을 모아서 표현한것이 바로 enum
//- 특정 타입들을 표시할때 사용하기 좋음

// 요일을 한번 enum으로 만들어 보겠습니다.
enum WeekDay {
    case mon
    case tue
    case wed
    case thu
    case fri
}

var today: WeekDay = .mon
//var today: WeekDay = WeekDay.fri
//var today = WeekDay.fri


// 미디어타입을 한번 enum으로 만들어 보겠습니다.
//enum MediaType {
//    case audio
//    case video
//}
//
//var mediaType: MediaType = .audio



//연관값(associated value)을 가지고 있는 형태로 표현도 가능합니다.
// 위에서 만들어본 미디어 타입에,
// 파일 확장자도 문자열로 받을수 있게 수정해보겠습니다.

enum MediaType {
    case audio(String)
    case video(String)
}

var mp3: MediaType = .audio("mp3")
var h264: MediaType = .video("h264")


//enum 을 표시할때 value 를 할당해서 표시해야할 때도 있음
//
//- Int 타입의 경우, 위의 케이스 부터 0부터 시작
//- String 의 경우, case 이름을 따르거나, 새로 지정할수 있음


enum MasterLevel: Int {
    case beginner
    case intermediate
    case professional
}

var beginner: MasterLevel = .beginner
beginner.rawValue

let pro = MasterLevel(rawValue: 2)
let otherLevel = MasterLevel(rawValue: 5) // -> nil

enum Direction: String {
    case up
    case down = "ddd"
//    case leftRight = "left_right" //서버에서 언더바
}

var dir: Direction = .down
dir.rawValue

let up = Direction(rawValue: "up")
let otherDirection = Direction(rawValue: "left") // -> nil
