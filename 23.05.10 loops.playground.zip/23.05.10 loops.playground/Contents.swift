import UIKit
//loops 반복문

//for loops

//- swift 에서 어떤 코드를 반복해서 수행할수 있는 메커니즘이 있음 → 그게 바로 loop
//- 그중에서 `for` loop를 이용해서 array, range 를 돌면서 코드를 반복 수행할수 있음
//    - (여기서 range 는 수의 어떤 범위를 표현하는 타입임)

// Range
//let numRange = 1..<10   1~9
let numRange = 1...10  // 1~10

for num in numRange {
    print("num is \(num)")
}

// Array
let names = ["John", "Kevin", "Jason"]

for name in names {
    print("name is \(name)")
}


//while loops

//- swift 에서 어떤 코드를 반복해서 수행할수 있는 메커니즘이 있음 → 그게 바로 loop
//- 그중에서 `while` loop 를 이용하면 특정 조건을 만족할때까지 코드를 반복 수행할수 있음

var num1 = 1

while num1 <= 20 {
    print(num1)
    num1 += 1
}

print("조건을 더 이상 만족하지 않아서, 탈출")


//# repeat loops

//- swift 에서 어떤 코드를 반복해서 수행할수 있는 메커니즘이 있음 → 그게 바로 loop
//- 그중에서 `repeat` loop 를 이용하면 특정 조건을 만족할때까지 코드를 반복 수행할수 있음
//    - `while` loop 와 다른점
//        - 코드를 수행하고 조건을 체크함 (while 은 조건을 먼저  체크하고 수행)

var num2 = 1

repeat {
    print(num2)
    num2 += 1
} while num2 <= 20

print("조건을 더 이상 만족하지 않아서, 탈출")


//exiting loop
//loop 를 돌다가 나가고 싶을때는 break 키워드를 이용해서 나갈수 있음


print("---> Exiting")

for i in 0...10 {
    if i == 4 {
        break
    }
    print(i)
}

var countDown1 = 10
while countDown1 > 0 {
    countDown1 -= 1
    if countDown1 == 3 {
        break
    }
    print(countDown1)
}

//skipping items
//loop 를 돌다가 스킵하고 싶은 loop 의 경우 continue 키워드를 이용해서 스킵 가능

print("---> Skipping")

for i in 0...10 {
    if i == 4 {
           continue
    }
    print(i)
}

var countDown2 = 10
while countDown2 > 0 {
    countDown2 -= 1
    if countDown2 == 3 {
           continue
    }
    print(countDown2)
}
