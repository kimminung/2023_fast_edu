import UIKit

let checking = { (id: String) -> Bool in
  if id == "User000" {
        return false
    }

    return true
}

func validate(id: String, checking: (String) -> Bool) -> Bool {
    // Some Preparation work here..
    print("Validation 준비중...")
    let isValid = checking(id)
    return isValid
}


let validationResult = validate(id: "User002", checking: checking) // true


// return 이 없는 클로져의 경우 "-> Void" 통해서 반환시키는 것이 없음을 표시함

let printHello = {
    print("Hello Swift")
}

func doSomeClosure(_ action: () -> Void) {
    action()
}

doSomeClosure(printHello)


let validationResult2 = validate(id: "User001", checking: { (id: String) in
    if id == "User000" {
          return false
      }

      return true
})

 
/*
 //closure의 인풋만 표시하고 리턴값 표시하지 않음. 시스템이 리턴을 추론함
let validationResult3 = validate(id: "User001", checking: { id in
    if id == "User000" {
              return false
          }
    
          return true
})
*/


//선언부 코드를 리펙토링하여 개선. 줄임
let validationResult3 = validate(id: "User001", checking: { id in

    let isValid = id != "User000"
    return isValid
})




doSomeClosure({
    print("Hello Swift")
})


/*
//이미 validate(id: String, checking: (String) -> Bool) -> Bool {를
//알고 있어서 추론한 것을 $0으로
let validationResult4 = validate(id: "User001", checking: { /*id in*/

    /*let isValid = */ /*id*/$0 != "User000"
     /*return isValid*/
})
*/

let validationResult4 = validate(id: "User001", checking: {$0 != "User000"
    
})

//trailing closure 마지막 파라미터 제거
let validationResult5 = validate(id: "User001"){$0 != "User000"}


validationResult
validationResult2
validationResult3
validationResult4
validationResult5
