import UIKit

//functions2

//default parameter

//- 파라미터에 기본값을 설정해줄수도 있음
//    - default 케이스에 대해서는 코드를 줄여서 심플하게 표현가능

func discount(price: Double, ratio: Double = 0.2) -> Double {
    return price * (1 - ratio)
}

let defaultRatioApplied = discount(price: 2000)
print(defaultRatioApplied)  // 1600

let customRatioApplied = discount(price: 2000, ratio: 0.5)
print(customRatioApplied)  // 1000


//variadic function 가변 함수

//- variadic function 이란
//    - 정해지지 않은 수의 여러 파라미터를 받을수 있은 형태의 함수를 의미함
//- 대표적으로 `print()` 함수가 있음
//- 함수 내부적으로 이렇게 받은 파라미터를 배열의 형태로 받음

func printNames(_ names: String...) {
    for name in names {
        print("name is \(name)")
    }
}

printNames("James", "Roy", "Jake")
// name is James
// name is Roy
// name is Jake


//throwing function

//- 함수 수행간에 예외 상황이 일어날수 있음
//    - 따라서, 제대로 함수를 수행할수 없는 경우 Error 을 내보내게 됨
//    - → 예를 들어, 잘못된 인풋, 네트워크 끊김
//- `throws` 키워드를 이용해서 만들수 있음
//- `throws` 가 있는 함수는   `try` 를 이용해 호출하고,  `do-catch`  를 이용해 에러 감지를 할수 있음

enum DivideError: Error {
    case cannotZero
}

func divide(dividend: Int, divisor: Int) throws -> Int {
    if divisor == 0 {
        throw DivideError.cannotZero
    }
    
    return Int(dividend / divisor)
}


do {
    let result = try divide(dividend: 80, divisor: 6)
    // let result = try divide(dividend: 80, divisor: 0)
    print(result)
} catch {
    print(error.localizedDescription)
}


//in-out parameter

//- 함수에서 넘겨 받는 input parameter 는 constant 임
//- 따라서 값을 변경할수 없음
//- `inout` 을 이용하면 변경가능함, 그리고 원래 오리지널 값도 변경이됨

func makeTriple(num: inout Int) {
    num *= 3
}

var num = 8
makeTriple(num: &num)

print(num)

