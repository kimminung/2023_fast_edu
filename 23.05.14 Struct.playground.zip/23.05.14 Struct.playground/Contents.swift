import UIKit

/*
object?

- 개발을 하게되면 가장 많이 마주치는 녀석
- 객체는 어떤 속성을 가지고 있고, 행동도 할수 있는 녀석
    - 예) 객체: 사람
        - 속성:
            - 피부색
            - 나이
            - 성별
            - 이름
        - 행동:
            - 밥을 먹는다
            - 배설을 한다
            - 일을 한다
- 객체들은 서로 모여서 협력함
- 객체들은 스스로의 책임이 있음
    - 책임 관점에서 객체는
        - 무엇인가 해야함
        - 정보를 알고 있음
*/

/*
object 어떻게 구현해?

- struct / class 를 이용해서 구현할수 있음
*/

/*
struct vs. class 차이점과 공통점

✅ 공통점
- 프로퍼티(속성)를 정의해서 값을 저장할수 있음
- 메소드(행동)를 정의해서 기능을 제공할수 있음
- 생성자를 정의해서 초기상태를 세팅할수 있음
- 확장을 이용해서, 기본 구현외 추가 기능을 더할수 있음
- 프로토콜을 구현해서 특정 기능을 제공할수 있음

✅ 차이점
- 클래스는 상속을 시킬수 있음
- 클래스는 레퍼런스 카운팅을 통해 클래스 인스턴스에 대한 하나 이상의 참조를 허용
- 클래스는 deinitializer 호출시, 이미 할당된 리소스에서 해제 할수 있음
*/

struct Movie {
    var name: String
}

//객체 인스턴스
var movie = Movie(name: "탑건")
print(movie.name)

movie.name = "탑건:매버릭"
print(movie.name)



/*
computed property 만들기

- 객체는 속성을 가지고 있고, 그것을 우리는 `property` 라고 부름
- swift 에는 값을 저장하고 있는  `stored property` 가 있음
    - 위 코드에서 `name` 은 영화이름을 저장하고 있는 `stored property` 임
- swift 에는 저장된 값이 아닌 계산된 값을 반환하는 `computed property`  도 있음
*/


struct Movie2 {
        // stored property
    var name: String
    var director: String

        // computed property
    var description: String {
        return "\(name) is \(director)'s best movie ever"
    }
}

//Movie 인스턴스
var movie2 = Movie2(name: "인셉션", director: "놀란")
print(movie2.description)

movie2.name //stored property
movie2.director //stored property
movie2.description //계산된 값을 보여줌.omputed property



//property observers

//- property 값이 변경되는 것을 감지할수도 있음

struct Task {
    var name: String
    var progress: Int {
        didSet {
            print("Current Progress : \(progress) %")
            
            // ***-------
            var str = ""
            for i in 1...10 {
                if progress >= i * 10 {
                    str += "*"
                } else {
                    str += "-"
                }
            }
            
            print("Current Progress : \(str)")
        }
    }
    
    
    var isDone: Bool {
        return progress == 100
    }
}


var task = Task(name: "Very Important Task", progress: 0)

task.progress = 30 // Current Progress : 30 %
task.progress = 50 // Current Progress : 50 %
task.progress = 90 // Current Progress : 90 %




//method

//- 객체는 행동(기능)을 가지고 있고, 그것을 우리는 `method` 라고 부름
//    - 객체가 가지고 있는 함수라고 생각하면 됨
//- `func` 키워드를 이용해서 구현함

struct Student {
    var name: String
    var major: String
    var knowledge: Double
    
    func didFinalTest() -> Int {
        let howMuchIdontKnow = (1 - knowledge) * 100
        let score = 100 - Int(howMuchIdontKnow)
        return score
    }
}


var student = Student(name: "Jason", major: "CS", knowledge: 0.9)

let score = student.didFinalTest() // 91


student.name
student.major
student.knowledge


/*
 mutating method

 - `struct` 인스턴스 생성시 `let` 을 이용해서 상수로 생성하면, property 변경 할수 없음
 - `struct` 인스턴스 생성시 `var` 을 이용해서 변수로 생성하면, property 변경 할수도 있고 없을수도 있음
     - 변경 가능한 경우
         - store property 가 `var` 로 선언된 경우
     - 변경 가능하지 않은 경우
         - store property 가 `let` 로 선언된 경우
 - `struct` 에서 `method` 가 `stored property` 값을 변경하는 경우, `mutating` 키워드를 메소드 앞에 붙여주어야함
 */

struct Student2 {
    let name: String
    var major: String
    var knowledge: Double
    
    func didFinalTest() -> Int {
        let howMuchIdontKnow = (1 - knowledge) * 100
        let score = 100 - Int(howMuchIdontKnow)
        return score
    }
    //프로퍼티 값을 변경시키는 메서드에는 뮤테이팅
    mutating func didStudy() {
        if knowledge >= 1 {
            knowledge = 1
        } else {
            knowledge += 0.1
        }
    }
}


var student2 = Student2(name: "Jason", major: "CS", knowledge: 0.5)

let score1 = student2.didFinalTest()

student2.didStudy()
student2.didStudy()

let score2 = student.didFinalTest()

// student.name = "ddd" // 에러 발생

