import UIKit

//struct

struct Movie {
    var name: String
}


var movie = Movie(name: "분노의 질주")
print(movie.name)

movie.name = "분노의 질주: 10"
print(movie.name)


struct Movie2 {
        // stored property
    var name: String
    var director: String

        // computed property
    var description: String {
        return "\(name) is \(director)'s best movie ever"
    }
}

var movie2 = Movie2(name: "인셉션", director: "놀란")
print(movie2.description)


struct Task {
    var name: String
    var progress: Int {
        didSet {
            print("Current Progress : \(progress) %")
        }
    }
    
    
    var isDone: Bool {
        return progress == 100
    }
}


var task = Task(name: "Very Important Task", progress: 0)

task.progress = 30 // Current Progress : 30 %
task.progress = 50 // Current Progress : 50 %
task.progress = 90 // Current Progress : 90 %



struct Student {
    var name: String
    var major: String
    var knowledge: Double
    
    func didFinalTest() -> Int {
        let howMuchIdontKnow = (1 - knowledge) * 100
        let score = 100 - Int(howMuchIdontKnow)
        return score
    }
}


var student = Student(name: "Jason", major: "CS", knowledge: 0.5)

let score = student.didFinalTest() // 50



struct Student2 {
    let name: String
    var major: String
    var knowledge: Double
    
    func didFinalTest() -> Int {
        let howMuchIdontKnow = (1 - knowledge) * 100
        let score = 100 - Int(howMuchIdontKnow)
        return score
    }
    
    mutating func didStudy() {
        if knowledge >= 1 {
            knowledge = 1
        } else {
            knowledge += 0.1
        }
    }
}


var student2 = Student2(name: "Jason", major: "CS", knowledge: 0.5)

let score1 = student.didFinalTest()

student2.didStudy()
student2.didStudy()

let score2 = student2.didFinalTest()

// student2.name = "ddd" // 에러 발생


let str = "Hello Swift"

print(str.count)  //  11

print(str.sorted())  //  [" ", "H", "S", "e", "f", "i", "l", "l", "o", "t", "w"]
print(str.split(separator: " "))  // ["Hello", "Swift"]
print(str.uppercased())  // HELLO SWIFT
print(str.hasPrefix("Hi")) // false



struct iPhone {
    var model: String
}

let iPhone13 = iPhone(model: "iPhone 13")


struct iPad {
    var model: String
}

let iPad2 = iPad(model: "iPad 2")



struct iPhone2 {
    var model: String

    init() {
        model = "iPhone 14"
    }
}

let iPhone14 = iPhone2()



struct iPhone3 {
    var model: String

    init(model: String = "iPhone 15") {
        self.model = model
    }
}

let iPhone15 = iPhone3()



struct Transactions {
    init() {
        print("Loading self history.. ")
    }
}


struct SecondHandItem {
    var name: String
    var history: Transactions = Transactions()
//    lazy var history: Transactions = Transactions()
    
    init(name: String) {
        self.name = name
    }
}


var usedMacbook = SecondHandItem(name: "M1 MacBook")

// usedMacbook.history



struct FCLecture {
    static var academyName: String = "Fast Campus"
    var name: String
}

var iOSLecture = FCLecture(name: "iOS 강의")
var backendLecture = FCLecture(name: "백엔드 강의")

print(iOSLecture.name) // "iOS 강의"
print(backendLecture.name) // "백엔드 강의"
print(FCLecture.academyName) // "Fast Campus"



struct UserAccount {
    var id: String
    var bill: Int
    var name: String
    
    init(id: String, bill: Int, name: String) {
        self.id = id
        self.bill = bill
        self.name = name
    }
    
    func billDescription() -> String {
        return "\(id)'s billing amount :\(bill)"
    }
}


var user01 = UserAccount(id: "1234", bill: 400, name: "Mike")

//user01.bill = 100
//user01.id = "1123"

let billDescription01 = user01.billDescription()



struct UserAccount2 {
    private var id: String
    private var bill: Int
    var name: String
    
    init(id: String, bill: Int, name: String) {
        self.id = id
        self.bill = bill
        self.name = name
    }
    
    func billDescription() -> String {
        return "\(id)'s billing amount :\(bill)"
    }
}


var user02 = UserAccount2(id: "1234", bill: 400, name: "Mike")

//user01.bill = 100
//user01.id = "1123"

let billDescription02 = user02.billDescription()
