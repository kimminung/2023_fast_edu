import UIKit

var greeting = "Hello, playground"


let first = 10
let second = 3

let sum = first + second
let diff = first - second

let multiple = first * second
let divided = first / second

let remainder = first % second


//operator overloading

//- 연산자는 타입에 따라 연산을 가질수 있음
//- 구체적으로 `+` 의 경우, `String` , array 등 각 타입에 따라 연산됨

let str1 = "aaa"
let str2 = "bbb"

let str = str1 + str2 // "aaabbb"

let names1 = ["April", "Bob"]
let names2 = ["Chuck", "David"]

let names = names1 + names2 // ["April", "Bob", "Chuck", "David"]


//compound operator

//- 연산자를 좀 더 줄여서 쓸수가 있음

var price1 = 10
price1 += 1 // 11

var price2 = 20
price2 -= 5 // 15

var price3 = 30
price3 *= 3 // 90

var price4 = 40
price4 /= 2 // 20


var quote = "Hello, Swift "
quote += "Playgrounds" // "Hello, Swift Playgrounds"


//comparison operator

//- 비교 연산자( `==` `!=` `>` `>=` … ) 를 이용해서 두 값을 비교 할수 있음

let score1 = 6
let score2 = 4

score1 == score2 // false
score1 != score2 // true

score1 > score2 // true
score1 >= score2 // true

score1 < score2 // false



//onditions //조건문

//- `if` 를 이용해서 조건에 따라 다른 프로그램이 실행 될수록 할수 있음

let num1 = 3
let num2 = 5

let sum1 = num1 + num2

if sum > 10 {
    print("over 10")
} else {
    print("not over 10")
}


//combining conditions

//- `if` 에 들어가는 조건들을 합칠수 있음 ( `&&` , `||`  를 이용함)


let age1 = 15
let age2 = 25

if age1 > 19 && age2 > 19 {
    print("19세 이상 영화를 같이 볼수 있겠네요")
} else {
    print("19세 이상 영화를 같이 볼수 없겠네요, 더 커서와라")
}

if age1 > 20 || age2 > 20 {
    print("20세 이상 보호자가 있으면 놀이공원에 들어갈수 있어요")
}


//ternary operator (삼항 연산자)

//- 삼항연산자를 이용해서 컨디션 확인 및 컨디션에 따른 값 할당이 가능함


let age3 = 30
let age4 = 40
                            //참   거짓
let text = age3 == age4 ? "same" : "not same"

/*
let text2: String
if age3 == age4 {
    text2 = "same"
} else {
    text2 = "not same"
}
*/

//switch statement

//- `if - else`  외에도 `switch` 를 이용해서 conditions을 확인할수 있음
//    - 다만, 조건의 모든케이스가 커버가 되게끔 작성해야함
//- 이전에 배웠던 `enum` 타입과 같이 쓰기 좋음

enum Direction {
    case up
    case down
    case left
    case right
}

let direction = Direction.down

switch direction {
case .up:
    print("up")
case .down:
    print("down")
case .left:
    print("left")
case .right:
    print("right")
}
