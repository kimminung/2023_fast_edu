import UIKit

import UIKit

//Swift: 클래스 (class) / 상속 (inheritance)

//object?

//- 개발을 하게되면 가장 많이 마주치는 녀석
//- 객체는 어떤 속성을 가지고 있고, 행동도 할수 있는 녀석
//    - 예) 객체: 사람
//        - 속성:
//            - 피부색
//            - 나이
//            - 성별
//            - 이름
//        - 행동:
//            - 밥을 먹는다
//            - 배설을 한다
//            - 일을 한다
//- 객체들은 서로 모여서 협력함
//- 객체들은 스스로의 책임이 있음
//    - 책임 관점에서 객체는
//        - 무엇인가 해야함
//        - 정보를 알고 있음

//object 어떻게 구현해?

//- struct / class 를 이용해서 구현할수 있음

//struct vs. class 차이점과 공통점

//✅ 공통점
//- 프로퍼티(속성)를 정의해서 값을 저장할수 있음
//- 메소드(행동)를 정의해서 기능을 제공할수 있음
//- 생성자를 정의해서 초기상태를 세팅할수 있음
//- 확장을 이용해서, 기본 구현외 추가 기능을 더할수 있음
//- 프로토콜을 구현해서 특정 기능을 제공할수 있음

//✅ 차이점
//- 클래스는 상속을 시킬수 있음
//- 클래스는 레퍼런스 카운팅을 통해 클래스 인스턴스에 대한 하나 이상의 참조를 허용
//- 클래스는 deinitializer 호출시, 이미 할당된 리소스에서 해제 할수 있음



//class 만들기

//- `class` 키워드를 이용해서 생성
//    - class 는 struct 와 다르게 memberwise initializer 제공되지 않음


class Dog {
    var name: String
    var breed: String

    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
}


let milk = Dog(name: "milk", breed: "Collie")

milk.name // milk
milk.breed // Collie


//class inheritance (클래스 상속)

//- `class` 와 `struct` 차이중 하나는 `class` 는 상속을 제공함
//- 상속을 이용하면, 기존 클래스를 이용해서 신규 클래스를 생성할수 있음
//    - 기존 클래스를 부모(parent) 또는 슈퍼(super) 클래스라고 부름
//    - 새로 생성한 클래스를 자식(child) 클래스 라고 부름


class Collie: Dog {
    init(name: String) {
        super.init(name: name, breed: "Collie")
    }
}

let milky = Collie(name: "milky")
milky.name // milkiy
milky.breed // Collie


//overriding method

//- 자식 클래스는 부모 클래스의 메소드를 그대로 쓸수 있음
//- 그리고, 자식 클래스는 부모 클래스의 메소드를 덮어써서 자식 클래스에 맞게 변형해서 쓸수 있음
//    - 이것을 `overriding` 이라고 함

class Dog2 {
    var name: String
    var breed: String

    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
    
    func bark() {
        print("bow wow")
    }
}


class Collie2: Dog2{
    init(name: String) {
        super.init(name: name, breed: "Collie")
    }
    
    override func bark() {
        print("wal wal")
    }
}


let nooni = Dog2(name: "Nooni", breed: "poodle")
let milky2 = Collie2(name: "milky")

nooni.bark() // bow wow
milky2.bark() // wal wal


//final class

//- 클래스 상속은 강력하지만, 가끔은 클래스 상속을 허용하지 않아야 할때가 있음
//- 이럴때 `final` 키워드를 이용해서 클래스 선언하면, 더 이상 상속 가능하지 않음

/*
 final class Dog3 {
    var name: String
    var breed: String

    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
    
    func bark() {
        print("bow wow")
    }
}

// Error: Inheritance from a final class 'Dog'
class Collie3: Dog3 {
    init(name: String) {
        super.init(name: name, breed: "Collie")
    }
    
    override func bark() {
        print("wal wal")
    }
}
*/


//copying object

//- `struct` 와 `class` 의 차이중 하나가 instance 복사할때임
//    - `struct` 와 같은 `value type` 은  복사하면, 새로운 객체를 만듬
//        - → 따라서, 새로 복사된 객체의 프로퍼티 변형했다고 원래 객체가 영향 받지 않음
//    - `class` 와 같은 `reference type` 은 복사하면, 새로운 객체를 만들지 않음 (같은 객체를 포인팅하고 있음)
//        - → 따라서, 새로 복사된 객체의 프로퍼티 변형하면, 원래 객체의 프로퍼티 영향 받아서 변형 되어 있음

class StudentClass {
    var name: String
    
    init(name: String) {
        self.name = name
    }
}

struct StudentStruct {
    var name: String
    
    init(name: String) {
        self.name = name
    }
}


var studentClass1 = StudentClass(name: "Jacob")
var studentClass2 = studentClass1

studentClass2.name = "Jay"
studentClass1.name // Jay
studentClass2.name // Jay

var studentStruct1 = StudentStruct(name: "Jacob")
var studentStruct2 = studentStruct1

studentStruct2.name = "Jay"
studentStruct1.name // Jacob
studentStruct2.name // Jay


//deinitializer

//- `struct` 와 `class` 의 차이중 하나가 `class` 는 `deinitializer` 가 있음
//- 해당 인스턴스가 메모리에서 해제될때(없어질때) 호출됨

class Human {
    var name: String
    
    init(name: String) {
        self.name = name
        print("initialize instance")
    }
    
    deinit {
        print("deintilize instance: \(name)")
    }
    
    func printName() {
        print("my name: \(self.name)")
    }
}


func createJohn() {
    let john = Human(name: "John")
    john.printName()
}

createJohn()

// initialize instance
// my name: John
// deintilize instance: John


//mutability

//- `class` 는 `struct` 와 다르게 `reference type` 이여서 상수로 선언하더라도, 프로퍼티가 `var` 로 선언해 놓았으면 변경 가능함
//    - 이 때문에,  class 는 method 앞에 `mutating` 키워드를 쓸 필요 없음
//    - 프로퍼티를 변경가능하지 않게 하려면, `let` 으로 선언해 놓으면 됨

class Human2 {
    var name: String
    
    init(name: String) {
        self.name = name
        print("initialize instance")
    }
    
    deinit {
        print("deintilize instance: \(name)")
    }
    
    func printName() {
        print("my name: \(self.name)")
    }
    
    func updateName(to name: String) {
        self.name = name
    }

}

let sean = Human2(name: "Sean")
sean.name // Sean
sean.updateName(to: "Son")
sean.name // Son

//읽어보기

//****Choosing Between Structures and Classes****

//[https://developer.apple.com/documentation/swift/choosing-between-structures-and-classes](https://developer.apple.com/documentation/swift/choosing-between-structures-and-classes)
