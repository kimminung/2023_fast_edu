import UIKit

let str = "Hello Swift"

print(str.count)  //  11

print(str.sorted())  //  [" ", "H", "S", "e", "f", "i", "l", "l", "o", "t", "w"]
print(str.split(separator: " "))  // ["Hello", "Swift"]
print(str.uppercased())  // HELLO SWIFT
print(str.hasPrefix("Hi")) // false //Hi로 시작하냐?


//initializer (생성자)

//- 해당 struct 를 만들수 있게 해주는 특별한 타입의 메소드
//    - `init` 키워드를 이용해서 생성함
//- struct 는 meberwise initializer 가 기본으로 따라옴

/*
struct iPhone {
    var model: String
}

let iPhone13 = iPhone(model: "iPhone 13")
*/

/*
 struct iPhone {
    var model: String

    init() {
        model = "iPhone 13"
    }
}

let iPhone13 = iPhone()
 
 */



//현재 객체 지칭하기

//- method 에서 현재 객체를 지칭할때 `self`  키워드를 이용함
//    - 특히, initializer 에서 파라미터와 내부 프로퍼티 이름간 구분을 지어줄때 용이함


/*
 struct iPhone {
    var model: String

    init() {
        self.model = "iPhone 13"
    }
}

let iPhone13 = iPhone()
 
 */

struct iPhone {
    var model: String

    init(model: String = "iPhone 13") {
        self.model = model
    }
}

let iPhone13 = iPhone()


//Lazy properties

//- 퍼포먼스 측면에서 인스턴스 생성시, 프로퍼티가 쓰이는 시점에 생성하는 방법이 있음
//- 바로 `lazy` 키워드를 이용하면 쓰이는 시점에 생성 가능

struct Transactions {
    init() {
        print("Loading self history.. ")
    }
}


struct SecondHandItem {
    var name: String
//    var history: Transactions = Transactions()
    lazy var history: Transactions = Transactions()
    
    init(name: String) {
        self.name = name
    }
}


var usedMacbook = SecondHandItem(name: "M1 MacBook")

 usedMacbook.history


//Static Methods & Properties

//- 지금까지 만든 메소드와 프로퍼티는 개별 인스턴스를 만들때 사용되는 것이였음
//- 개별 인스턴스와 달리, 해당 타입의 속성, 해당 타입 자체의 메소드를 만들어야 할때가 있음 (따라서 타입 메소드, 타입 프로퍼티 라고 부름)
//    - 이때 `static` 키워드를 이용해서 타입의 속성 및 메소드를 정의 할수 있음
//    -

struct FCLecture {
    static var academyName: String = "Fast Campus"
    var name: String
}

var iOSLecture = FCLecture(name: "iOS 강의")
var backendLecture = FCLecture(name: "백엔드 강의")

print(iOSLecture.name) // "iOS 강의"
print(backendLecture.name) // "백엔드 강의"
print(FCLecture.academyName) // "Fast Campus"


/*
 Access Control

 - 객체간 협력을 하다보면, 협력 객체가 현재 객체에 접근할때가 있음
 - 그러다 보면, 외부 객체가 현재 객체의 프로퍼티등을 임의로 수정할때가 있음
     - 다만, 외부 객체가 수정하면 안되는 경우가 있음
     - 이때 프로퍼티 및 메소드의 접근 제어(access control)를 할수 있음
 - 접근 제어
     - 외부 접근 가능 >  `public`  > `internal` > `fileprivate`  > `private` > 내부 접근 가능

 */

// 접근 제어가 안되었을 때

struct UserAccount {
    var id: String
    var bill: Int
    var name: String
    
    init(id: String, bill: Int, name: String) {
        self.id = id
        self.bill = bill
        self.name = name
    }
    
    func billDescription() -> String {
        return "\(id)'s billing amount :\(bill)"
    }
}


var user01 = UserAccount(id: "1234", bill: 400, name: "Mike")

user01.bill = 100
user01.id = "1123"

let billDescription01 = user01.billDescription()
print(billDescription01)


// 접근 제어가 되었을 때

struct UserAccount2 {
    private var id: String
    private var bill: Int
    var name: String
    
    init(id: String, bill: Int, name: String) {
        self.id = id
        self.bill = bill
        self.name = name
    }
    
    func billDescription() -> String {
        return "\(id)'s billing amount :\(bill)"
    }
}


var user02 = UserAccount2(id: "1234", bill: 400, name: "Mike")

//user01.bill = 100
//user01.id = "1123"

let billDescription02 = user02.billDescription()
print(billDescription02)
