import UIKit

var greeting = "Hello, playground"

import UIKit

//Protocol?

/*
- `protocol` 은 어떤 약속(역할)을 정해 놓은것
    - 여기서 약속이라 하면,
        - properties
        - method
    - 예를 들어: `학급 반장` 이란 프로토콜이 있다면,
        - `학급 반장` 의 속성에는
            - 이름
            - 해당 학급반
        - `학급 반장` 이 할일에는
            - 학급 대표로 선생님께 인사하기
            - 소풍갈때 인원 점검하기
- 어떤 약속(역할)을 정해 놓은것이지 아직 구현된것은 아님
    - 따라서, 개발할때는 어떤 객체가 해당 역할을 수행할지 정하고
    - 그 다음에 해당 객체가 그 역할을 어떻게 구현할지 정하면 됨
    - 이것을 `protocol conforming(채택?, 준수?)` 이라고 함
*/

protocol ClassPresident {
    var name: String { get }
    var className: String { get }
    
    func sayHello()
    func checkClassMember()
}


struct UnivPresidentStudent: ClassPresident {
    var name: String
    var className: String
    
    func sayHello() {
        print("대학생: 교수님 안뇽하세용!")
    }
    
    func checkClassMember() {
        print("대학생: 애들아 다 왔니?, 이제 니네도 어른이다. 알아서 하자!")
    }
}


struct HighSchoolPresidentStudent: ClassPresident {
    var name: String
    var className: String
    
    func sayHello() {
        print("고등학생: 담임 선생님 안뇽하세용!")
    }
    
    func checkClassMember() {
        print("고등학생: 애들아 다 왔니?")
    }
}

let jason = UnivPresidentStudent(name: "Jason", className: "공대")
let jake = HighSchoolPresidentStudent(name: "Jake", className: "이과")


jason.sayHello()
jason.checkClassMember()
// 대학생: 교수님 안뇽하세용!
// 대학생: 애들아 다 왔니?, 이제 니네도 어른이다. 알아서 하자!

jake.sayHello()
jake.checkClassMember()
// 고등학생: 담임 선생님 안뇽하세용!
// 고등학생: 애들아 다 왔니?


//Protocol 왜 필요해?

/*
- 개발하다 보면 다양한 객체를 만들게 됨
- 다양한 객체간에 공통 역할을 발견하게 됨
- 해당 역할을 한정된 객체에서만 쓰지 않고, 여러 객체로 확장이 필요할때가 있음
- 이럴때, 그 역할을 프로토콜로 정의하고
- 해당 역할이 필요한 객체나올때 마다,  해당 프로토콜을 채택해서 역할을 줄수 있음

### 한가지 객체에 대해서만 buy() 메소드를 정의할때
*/

struct Book {
    var name: String
}

func buy(_ book: Book) {
    print("I'm buying \(book.name)")
}

let harrypotter = Book(name: "Harry Potter")
buy(harrypotter)

// Purchaseable  역할에 buy() 메소드를 정의할때

protocol Purchaseable {
    var name: String { get set }
}

func buy(_ item: Purchaseable) {
    print("I'm buying \(item.name)")
}


struct Book: Purchaseable {
    var name: String
    var author: String
}

struct Movie: Purchaseable {
    var name: String
    var actors: [String]
}

struct Car: Purchaseable {
    var name: String
    var manufacturer: String
}

struct Coffee: Purchaseable {
    var name: String
    var strength: Int
}

let harryPotter = Book(name: "HarryPotter", author: "J.K. Rowling")

let topgun = Movie(name: "Top Gun", actors: ["Tom cruise"])

let modelX = Car(name: "modelX", manufacturer: "Tesla")

let americano = Coffee(name: "ahah", strength: 5)

buy(harryPotter)
buy(topgun)
buy(modelX)
buy(americano)


// Protocol 상속

/*
- `protocol` 은 상속 받을수 있음
- 클래스와 다르게 여러개 상속이 가능함
    - 여러개 상속이 되다 보니, `protocol` 을 더 작고 명확하게 나눌수 있음
    - 재사용성도 늘고 테스트 가능성도 더 높아짐
*/

protocol Payable {
    func calculateWages() -> Int
}

protocol Trainable {
    func train()
}

protocol HasVacation {
    func takeVacation(days: Int)
}

protocol Employee: Payable, Trainable, HasVacation { }

struct DeveloperEmployee: Employee {
    var name: String
    
    func calculateWages() -> Int {
        return 10_000_000
    }
    
    func train() {
        print("study hard")
    }
    
    func takeVacation(days: Int) {
        print("take \(days) days off")
    }
}

let choi = DeveloperEmployee(name: "Choi")

choi.calculateWages()
choi.takeVacation(days: 3)
choi.train()





// Extension?

//- `extension`  기존에 있던 타입에 기능을 추가 할수 있게 해줌


extension Int {
    func squared() -> Int {
        return self * self
    }
}

let number = 8
number.squared() // 64

extension Int {
    var isEven: Bool {
        return self % 2 == 0
    }
}

number.isEven // true


// Protocol Extension

/*
- `protocol` 은 어떤 역할에 대한 정의를 설명해줌
    - 다만, 실제 구현은 제공하지 않음
- `extension` 은 기능에 대한 구현까지 제공함
    - 다만, 한가지 타입에만 적용됨
- `protocol extension` 은 위에 있는 두가지 단점을 보완해 줄수 있음
    - `protocol` 에 기본 구현을 제공해줄수 있음
    - `protocol` 을 채택하는 여러 타입에 기능을 제공해줄수 있음
*/

extension Collection {
    func summarize() {
        print("There are \(count) members")
    }
}

let stringArray = ["aa", "bb", "cc"]
let numSet = Set([1, 2, 3, 4, 5])

stringArray.summarize()
// There are 3 members

numSet.summarize()
// There are 5 members



// Protocol Oriented Programming

/*
- `protocol` 은 어떤 역할에 대한 정의를 제공
- `extension` 은 어떤 타입에 구현을 제공함
- `protocol extension` 은 어떤 역할에 대한 기본 구현 제공
- 위 3가지 덕분에 POP(protocol oriented programming)이 가능함
*/


protocol Payable {
    func calculateWages() -> Int
}

protocol Trainable {
    func train()
}

protocol HasVacation {
    func takeVacation(days: Int)
}

extension Payable {
    func calculateWages() -> Int {
        return 10_000_000
    }
}

extension Trainable {
    func train() {
        print("study hard")
    }
}

extension HasVacation {
    func takeVacation(days: Int) {
        print("take \(days) days off")
    }
}

protocol Employee: Payable, Trainable, HasVacation { }

struct DeveloperEmployee: Employee {
    var name: String
}

let choi = DeveloperEmployee(name: "Jason")

choi.calculateWages()
choi.takeVacation(days: 3)
choi.train()


struct DesignerEmployee: Employee {
    var name: String
}

let jane = DesignerEmployee(name: "jane")
jane.calculateWages()
jane.takeVacation(days: 5)
jane.train()
