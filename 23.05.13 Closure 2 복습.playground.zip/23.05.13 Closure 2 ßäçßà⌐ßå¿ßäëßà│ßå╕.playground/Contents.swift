import UIKit

//func validate(id: String, checking: (String) -> Bool) -> Bool {
//    // Some Preparation work here..
//    print("Validation 준비중...")
//    let isValid = checking(id)
//    return isValid
//}
//
//
//let validationResult = validate(id: "User002", checking: checking) // true
//
//
//// return 이 없는 클로져의 경우 "-> Void" 통해서 반환시키는 것이 없음을 표시함
//
//let printHello = {
//    print("Hello Swift")
//}
//
//func doSomeClosure(_ action: () -> Void) {
//    action()
//}
//
//doSomeClosure(printHello)

let checking = { (id: String) -> Bool in
    if id == "User000" {
        return false
    }
    return true
}

//let isValid = checking("User123")

func validate(id: String, checking: (String) -> Bool) -> Bool {
    print("Validation 준비중...")
    let isValid = checking(id)
    return isValid
}

let validationResult = validate(id: "User002", checking: checking)

let printHello = {
//let printHello = { () -> Void in
    print("Hello Swift")
}

func doSomeClosure(_ action: () -> Void) {
    action()
}

doSomeClosure(printHello)


//let printHello = {
////let printHello = { () -> Void in
//    print("Hello Swift")
//}
//
//func doSomeClosure(_ action: () -> Void) {
//    action()
//}
//
//doSomeClosure(printHello)


let validationResult2 = validate(id: "User001",
    checking: { (id: String) -> Bool in
    if id == "User000" {
          return false
      }

      return true
})
/*
validate(id: "User001", checking: { (id: String) -> Bool in
    if id == "User000" {
        return false
    }
    return true
})
*/

doSomeClosure({
    print("Hello Swift")
})

//doSomeClosure({
//    print("...aaa")
//})
