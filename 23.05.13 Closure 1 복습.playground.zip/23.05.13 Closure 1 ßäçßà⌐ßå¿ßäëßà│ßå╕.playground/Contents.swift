import UIKit

//let checking = {
//    print("checking 🔥🔥🔥")
//}
//
//checking() // "checking 🔥🔥🔥"


//let checking = {
//    print("checking !!")
//}
//
//checking()



//let checking = { (id: String) in
//    print("checking 🔥🔥🔥 id:\(id)")
//}
//
//checking("User123") // "checking 🔥🔥🔥 id:User123"


//let checking = { (id: String) in
//    print("checking !!! id: \(id)")
//}
//
//checking("User123")




// blocked User: User000

//let checking = { (id: String) -> Bool in
//  if id == "User000" {
//        return false
//    }
//
//    return true
//}
//
//let isValid = checking("User123") // true
//// let isValid = checking("User000") // false


let checking = { (id: String) -> Bool in
    if id == "User000" {
        return false
    }
    return true
}

let isValid = checking("User123")
// let isValid = checking("User000")
