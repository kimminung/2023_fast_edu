import UIKit

class Dog {
    var name: String
    var breed: String

    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
}


let milk = Dog(name: "milk", breed: "Collie")

milk.name // milk
milk.breed // Collie


class Collie: Dog {
    init(name: String) {
        super.init(name: name, breed: "Collie")
    }
}

let milky = Collie(name: "milky")
milky.name // milkiy
milky.breed // Collie


class Dog {
    var name: String
    var breed: String

    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
    
    func bark() {
        print("bow wow")
    }
}


class Collie: Dog {
    init(name: String) {
        super.init(name: name, breed: "Collie")
    }
    
    override func bark() {
        print("wal wal")
    }
}


let nooni = Dog(name: "Nooni", breed: "poodle")
let milky = Collie(name: "milky")

nooni.bark() // bow wow
milky.bark() // wal wal


final class Dog {
    var name: String
    var breed: String

    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
    
    func bark() {
        print("bow wow")
    }
}

// Error: Inheritance from a final class 'Dog'
class Collie: Dog {
    init(name: String) {
        super.init(name: name, breed: "Collie")
    }
    
    override func bark() {
        print("wal wal")
    }
}


class StudentClass {
    var name: String
    
    init(name: String) {
        self.name = name
    }
}

struct StudentStruct {
    var name: String
    
    init(name: String) {
        self.name = name
    }
}


var studentClass1 = StudentClass(name: "Jacob")
var studentClass2 = studentClass1

studentClass2.name = "Jay"
studentClass1.name // Jay
studentClass2.name // Jay

var studentStruct1 = StudentStruct(name: "Jacob")
var studentStruct2 = studentStruct1

studentStruct2.name = "Jay"
studentStruct1.name // Jacob
studentStruct2.name // Jay


class Human {
    var name: String
    
    init(name: String) {
        self.name = name
        print("initialize instance")
    }
    
    deinit {
        print("deintilize instance: \(name)")
    }
    
    func printName() {
        print("my name: \(self.name)")
    }
}


func createJohn() {
    let john = Human(name: "John")
    john.printName()
}

createJohn()

// initialize instance
// my name: John
// deintilize instance: John



class Human {
    var name: String
    
    init(name: String) {
        self.name = name
        print("initialize instance")
    }
    
    deinit {
        print("deintilize instance: \(name)")
    }
    
    func printName() {
        print("my name: \(self.name)")
    }
    
    func updateName(to name: String) {
        self.name = name
    }

}

let sean = Human(name: "Sean")
sean.name // Sean
sean.updateName(to: "Son")
sean.name // Son
