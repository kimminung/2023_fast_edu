import UIKit

//closure?

//- 클로져도 사실 함수처럼 “어떤 태스크를 수행하기 위한 코드 블록” 임
//- 사실 클로져는 크게 아래와 같이 나뉨
//    - 이름이 있는 클로져 → 함수
//    - 이름이 없는 클로져 → 이번에 배울것
//- closure 형태는 아래와 같음

/*
{ (parameters) -> return type in

   statements

}
 */

//- `in`  기준으로 `클로져 선언부`와  `클로져 실행부` 가 나뉨
//    - 클로져 선언부:  파라미터와 리턴타입 명시
//    - 클로져 실행부: 실행 코드 작성
//- swift 에서는 클로져, 함수를 타입으로 사용할수 있음
//    - 따라서, 변수에 할당할수 있고, 다른 함수 파라미터로 전달할수도 있음

let checking = {
    print("checking 🔥🔥🔥")
}

checking() // "checking 🔥🔥🔥"


//input parameter

//- 클로져도 파라미터를 받을수 있음


let checking2 = { (id: String) in
    print("checking2 🔥🔥🔥 id:\(id)")
}

checking2("User123") // "checking 🔥🔥🔥 id:User123"

//returning value

//- 클로져는 특정값을 반환 할수도 있음


// blocked User: User000

let checking3 = { (id: String) -> Bool in
  if id == "User000" {
        return false
    }

    return true
}

let isValid = checking3("User123") // true
// let isValid = checking3("User000") // false
